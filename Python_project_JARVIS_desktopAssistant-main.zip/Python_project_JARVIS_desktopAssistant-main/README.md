# Python_project_JARVIS_desktopAssistant

Built a backend-only personal assistant in Python powered by the Gemini API to handle tasks like fetching real-time information,answering queries, and executing system commands. Designed it with a focus on speed, accuracy, and clean modular code, evenwithout a graphical interface. This project strengthened my skills in API integration, automation, and backend logic, while giving mehands-on experience in building practical, real-world tools from scratch.
